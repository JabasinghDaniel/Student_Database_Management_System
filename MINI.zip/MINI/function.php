<?php


function showdetails($standard,$rollno){
    include('dbcon.php');

    $qry1 = "SELECT * FROM `student` WHERE `rollno`='$rollno' AND `standard`='$standard'";
    $qry2 = "SELECT * FROM `attendence` WHERE `usn`='$rollno' ";
    $qry3 = "SELECT * FROM `grade` WHERE `usn`='$rollno' ";
    $qry4 = "SELECT * FROM `other` WHERE `usn`='$rollno' ";
    
    
    $run1 = mysqli_query($con,$qry1);
    $run2 = mysqli_query($con,$qry2);
    $run3 = mysqli_query($con,$qry3);
    $run4 = mysqli_query($con,$qry4);



    if(mysqli_num_rows($run1)>0){
        $data1 = mysqli_fetch_assoc($run1);
        $data2 = mysqli_fetch_assoc($run2);
        $data3 = mysqli_fetch_assoc($run3);
        $data4 = mysqli_fetch_assoc($run4);
        ?>
 <style>
  .center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
 }
                       
#customers {
  font-family: 'Times New Roman', Times, serif, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(odd){background-color: #f2f2f2;}
#customers tr:nth-child(even){background-color: #f2f2f2;}
#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #000080;
  color: white;
}

         </style>              
        <table align="center"  id="customers" border="1" style="width:50%; margin-top:40px;">


               <tr style="height:40px">
        <td colspan="3"  align="center"> <font size="5"><b>Student Details</b></font></td>
       </tr>
            <tr>
                <td rowspan="6"><img src="dataimg/<?php echo $data1['image']; ?>" width="200" height="200" class="center" ></td>
                <th>Roll No</th>
                <td align="center"><?php echo $data1['rollno'] ?></td>
                
           </tr>
            <tr>
                <th>Name</th>
                <td align="center"><?php echo $data1['name'] ?></td>
            </tr>
            <tr>
            <th>Date of Birth</th>
            <td align="center"><?php echo $data4['DOB'] ?></td>
             </tr>
            <tr>
                <th>Address</th>
                <td align="center"><?php echo $data1['city'] ?></td>
            </tr>
            <tr>
                <th>Mobile number</th>
                <td align="center"><?php echo $data1['pcont'] ?> </td>
            </tr>
            <tr>
                <th>Semester</th>
                <td align="center"><?php echo $data1['standard'] ?>th Sem </td>
            </tr>

            
            <tr style="height:40px">
        <td colspan="3"  align="center"> <font size="5"><b>Attendence</b></font></td>
       </tr>
        <tr>
            <th>January</th>
            <td  colspan="2" align="center"><?php echo $data2['jana'] ?>%</td>
        </tr>
        <tr>
            <th>February</th>
            <td colspan="2"  align="center"><?php echo $data2['febr'] ?>%</td>
        </tr>
        
            <th>March</th>
            <td colspan="2" align="center"><?php echo $data2['marc'] ?>%</td>
        </tr>
        <tr>
            <th>April</th>
            <td colspan="2" align="center"><?php echo $data2['apri'] ?>%</td>
        </tr>
        <tr>
            <th>May</th>
            <td colspan="2" align="center"><?php echo $data2['may'] ?>%</td>
        </tr>
        <tr>
        <tr>
            <th>June</th>
            <td colspan="2" align="center"><?php echo $data2['june'] ?>%</td>
        </tr>
        <tr>
            <th>July</th>
            <td colspan="2" align="center"><?php echo $data2['july'] ?>%</td>
        </tr>
        
        <tr>
            <th>Augest</th>
            <td colspan="2" align="center"><?php echo $data2['auge'] ?>%</td>
        </tr>
        <tr>
            <th>September</th>
            <td colspan="2" align="center"><?php echo $data2['sept'] ?>%</td>
        </tr>
        <tr>
            <th>October</th>
            <td colspan="2" align="center"><?php echo $data2['octo'] ?> %</td>
        </tr>
        <tr>
            <th>November</th>
            <td colspan="2" align="center"><?php echo $data2['nove'] ?>%</td>
        </tr>
        <tr>
            <th>Decemberr</th>
            <td colspan="2" align="center"><?php echo $data2['dece'] ?>%</td>
        </tr>
        <tr> 
    


        <tr style="height:40px">
        <td colspan="3"  align="center"> <font size="5"><b>Grade Points</b></font></td>
       </tr>
        <tr>
            <th>1st Sem SGPA</th>
            <td colspan="2" align="center"> <?php echo $data3['semester1'] ?></td>
        </tr>
        <tr>
            <th>2nd Sem SGPA</th>
            <td colspan="2" align="center"><?php echo $data3['semester2'] ?></td>
        </tr>
        
            <th>3rd Sem SGPA</th>
            <td colspan="2" align="center"><?php echo $data3['semester3'] ?></td>
        </tr>
        <tr>
            <th>4th Sem SGPA</th>
            <td colspan="2"  align="center"><?php echo $data3['semester4'] ?></td>
        </tr>
        <tr>
            <th>5th Sem SGPA</th>
            <td colspan="2" align="center"><?php echo $data3['semester5'] ?></td>
        </tr>
        <tr>
        <tr>
            <th>6th Sem SGPA</th>
            <td colspan="2" align="center"><?php echo $data3['semester6'] ?></td>
        </tr>
        <tr>
            <th>7th Sem SGPA</th>
            <td colspan="2" align="center"><?php echo $data3['semester7'] ?></td>
        </tr>
        
        <tr>
            <th>8th Sem SGPA</th>
            <td colspan="2" align="center"><?php echo $data3['semester8'] ?></td>
        </tr>
        <tr>
        <tr>
        <th>Current CGPA</th>
            <td colspan="2" align="center"><?php echo $data3['cgpa'] ?></td>
        </tr>
        <tr>


        <tr style="height:60px">
             <td colspan="3"  align="center"> <font size="5"><b>Other Details</b></font></td>
        </tr>
        
        <tr>
            <th>Father Name</th>
            <td colspan="2" align="center"><?php echo $data4['father']?></td>
        </tr>
        
            <th>Mother Name</th>
            <td colspan="2" align="center"><?php echo $data4['mother'] ?></td>
        </tr>
        <tr>
            <th>Parent Mobile No.</th>
            <td colspan="2" align="center"><?php echo $data4['pnumber'] ?></td>
        </tr>
            

<?php
        
        
        
        
    }
    
    else{
        echo"<script>alert('No Student Found'); </script>";
    }
}


?>

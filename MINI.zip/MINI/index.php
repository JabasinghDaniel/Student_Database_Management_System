<html>
    <head>
        <meta charset ="UTF-8">
        <link rel="stylesheet" href="index.css">
        <script src="jquery-3.3.1.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <style>

.button2 {background-color:whitesmoke;
    font-family: 'Times New Roman', Times, serif;
            border-radius: 12px;
            border: none;
        color: whitesmoke;
        padding: 20px 34px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;} 

        .button1 {background-color:white;
    font-family: 'Times New Roman', Times, serif;
            border-radius: 12px;
            border: none;
        color: black;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
            }

    body {font-family: 'Times New Roman', Times, serif;
         background-image: url('dataimg/indexpage.jpg');
        background-repeat: no-repeat;
         background-attachment: fixed;  
         background-size: cover;
         }

         h1 {
        font-size: 40px;
        color: white;
         font-family: 'Times New Roman', Times, serif;
             }
             h3{
      font-size: 30px;
         color: rgb(255, 252, 252);
         }

</style>
        <title> Student Management System</title>
        
    </head>
    <body>
  
        <h3 align="right" > <button class=" button2" ><a style="text-decoration: none"   href="login.php">Admin Login</a></button></h3>
       
        <h1 align="center"> Student Database System</h1>
        <h1> <marquee width="100%" direction="left" height="30%">
    Srinivas Institute of Technology,Valachil,Manglore.
</marquee></h1>
        
        
        <form method="post" action="index.php" >
            <table style="height:30%;width :40%;" align="center" border="1">
                <tr>
                    <td colspan="2" align="center" style="color : black; font-size: 30px;"><b>Student Information</b></td>
                </tr>
                <tr>
                    <td align="center" style="color : white; font-size: 20px;"><b> Enter Semester</b></td>
                    <td>
                        <select name="std">
                            <option value="1">1st</option>
                            <option value="2">2nd</option>
                            <option value="3">3rd</option>
                            <option value="4">4th</option>
                            <option value="5">5th</option>
                            <option value="6">6th</option>
                            <option value="7">7th</option>
                            <option value="8">8th</option>
                            
                        </select>
                                   
                    </td>
                </tr>
                <tr>
                <td align="center" style="color : white; font-size: 20px;"><b>Enter USN</b></td>
                    <td><input type="text" name="rollno"</td>
                </tr>
                <tr>
                    <td  colspan="2" align="center"><input  class=" button1"  type="submit" name="submit" value="View"></td>
                </tr>
            </table>
                                   
        </form>
            
            
        
        
        
    </body>
    
</html>

<?php

if(isset($_POST['submit'])){
    
    $standard= $_POST['std'];
    $rollno = $_POST['rollno'];
    
    include('dbcon.php');
    include('function.php');
    
    showdetails($standard,$rollno);
    
    
    
    
    
    
}

?>
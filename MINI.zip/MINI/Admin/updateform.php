<?php
session_start();
if(isset($_SESSION['uid']))
{
    echo "";
}
/*else{
    header('location: ../login.php');
}*/
  
?>

<?php
include('header.php');
include('titleheader.php');
include('../dbcon.php');

$sid = $_GET['sid'];

$sql1 = "SELECT * FROM `student` WHERE `rollno` = '$sid'";
$sql2 = "SELECT * FROM `attendence` WHERE `usn` = '$sid'";
$sql3 = "SELECT * FROM `grade` WHERE `usn` = '$sid'";
$sql4 = "SELECT * FROM `other` WHERE `usn` = '$sid'";

$run1 = mysqli_query($con,$sql1);
$run2 = mysqli_query($con,$sql2);
$run3 = mysqli_query($con,$sql3);
$run4 = mysqli_query($con,$sql4);

$data1=mysqli_fetch_assoc($run1);
$data2=mysqli_fetch_assoc($run2);
$data3=mysqli_fetch_assoc($run3);
$data4=mysqli_fetch_assoc($run4);

?>

<h1 align="center">Edit The Data</h1>
<form method="post" action="updatedata.php" enctype="multipart/form-data">
    
    <table align="center" border="1" style="width:70%; margin-top:40px;">
       <tr style="height:60px">
             <td colspan="2"  align="center"> <font size="5"><b>Personal Details</b></font></td>
        </tr>
        <tr>
            <th>USN</th>
            <td><input type="text" name="rollno" value=<?php echo $data1['rollno'] ?> required></td>
        </tr>
        <tr>
            <th>Full Name</th>
            <td><input type="text" name="name" value=<?php echo $data1['name'] ?> required></td>
        </tr>
        <tr>
        <tr>
            <th>City</th>
            <td><input type="text" name="city" value=<?php echo $data1['city'] ?> required></td>
        </tr>
        <tr>
            <th>Parents Contact no.</th>
            <td><input type="text" name="pcon" value=<?php echo $data1['pcont'] ?> required></td>
        </tr>
        <tr>
            <th>Semester</th>
            <td><input type="number" name="standard" value=<?php echo $data1['standard'] ?> required></td>
        </tr>
        <tr>
            <th>Image</th>
            <td><input type="file" name="simg" required> </td>
        </tr>



        <tr style="height:60px">
        <td colspan="2"  align="center"> <font size="5"><b>Attendence</b></font></td>
       </tr>
        <tr>
            <th>January</th>
            <td><input type="number" name="jan" value=<?php echo $data2['jana'] ?>></td>
        </tr>
        <tr>
            <th>February</th>
            <td><input type="number" name="feb" value=<?php echo $data2['febr'] ?>></td>
        </tr>
        
            <th>March</th>
            <td><input type="number" name="mar" value=<?php echo $data2['marc'] ?>></td>
        </tr>
        <tr>
            <th>April</th>
            <td><input type="number" name="apr" value=<?php echo $data2['apri'] ?>></td>
        </tr>
        <tr>
            <th>May</th>
            <td><input type="number" name="may" value=<?php echo $data2['may'] ?>></td>
        </tr>
        <tr>
        <tr>
            <th>June</th>
            <td><input type="number" name="jun" value=<?php echo $data2['june'] ?>></td>
        </tr>
        <tr>
            <th>July</th>
            <td><input type="number"name="jul" value=<?php echo $data2['july'] ?>></td>
        </tr>
        
        <tr>
            <th>Augest</th>
            <td><input type="number" name="aug" value=<?php echo $data2['auge'] ?>></td>
        </tr>
        <tr>
            <th>September</th>
            <td><input type="number" name="sep" value=<?php echo $data2['sept'] ?>></td>
        </tr>
        <tr>
            <th>October</th>
            <td><input type="number" name="oct" value=<?php echo $data2['octo'] ?> ></td>
        </tr>
        <tr>
            <th>November</th>
            <td><input type="number" name="nov" value=<?php echo $data2['nove'] ?>></td>
        </tr>
        <tr>
            <th>Decemberr</th>
            <td><input type="number" name="dec" value=<?php echo $data2['dece'] ?>></td>
        </tr>
        <tr> 
    


        <tr style="height:60px">
        <td colspan="2"  align="center"> <font size="5"><b>Grade Points</b></font></td>
       </tr>
        <tr>
            <th>1st Sem SGPA</th>
            <td><input type="number" name="sem1" value=<?php echo $data3['semester1'] ?>></td>
        </tr>
        <tr>
            <th>2nd Sem SGPA</th>
            <td><input type="number" name="sem2" value=<?php echo $data3['semester2'] ?>></td>
        </tr>
        
            <th>3rd Sem SGPA</th>
            <td><input type="number" name="sem3" value=<?php echo $data3['semester3'] ?>></td>
        </tr>
        <tr>
            <th>4th Sem SGPA</th>
            <td><input type="number" name="sem4" value=<?php echo $data3['semester4'] ?>></td>
        </tr>
        <tr>
            <th>5th Sem SGPA</th>
            <td><input type="number" name="sem5" value=<?php echo $data3['semester5'] ?>></td>
        </tr>
        <tr>
        <tr>
            <th>6th Sem SGPA</th>
            <td><input type="number" name="sem6" value=<?php echo $data3['semester6'] ?>></td>
        </tr>
        <tr>
            <th>7th Sem SGPA</th>
            <td><input type="number"name="sem7" value=<?php echo $data3['semester7'] ?>></td>
        </tr>
        
        <tr>
            <th>8th Sem SGPA</th>
            <td><input type="number" name="sem8" value=<?php echo $data3['semester8'] ?>></td>
        </tr>
        <tr>
        <tr>
        <th>Current CGPA</th>
            <td><input type="number" name="cgpa" value=<?php echo $data3['cgpa'] ?>></td>
        </tr>
        <tr>


        <tr style="height:60px">
             <td colspan="2"  align="center"> <font size="5"><b>Other Details</b></font></td>
        </tr>
        <tr>
            <th>Date of Birth</th>
            <td><input type="Date" name="dob" value=<?php echo $data4['DOB'] ?> required></td>
        </tr>
        <tr>
            <th>Father Name</th>
            <td><input type="text" name="fname" value=<?php echo $data4['father'] ?> required></td>
        </tr>
        
            <th>Mother Name</th>
            <td><input type="text" name="mname" value=<?php echo $data4['mother'] ?> required></td>
        </tr>
        <tr>
            <th>Parent Mobile No.</th>
            <td><input type="text" name="pmnum" value=<?php echo $data4['pnumber'] ?> required></td>
        </tr>
        
        <tr>
            <td colspan="2" align="center">
                <input type="hidden" name="sid"value="<?php echo $data['rollno']; ?>"/> 
                <input type="submit" name="submit" value="Submit"></td>
        </tr>
    </table>
</form>

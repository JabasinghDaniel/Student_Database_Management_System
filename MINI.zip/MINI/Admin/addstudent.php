<?php

session_start();
if(isset($_SESSION['uid']))
{
    echo "";
}
/*else{
    header('location: ../login.php');
}*/
  
?>

<?php

include('header.php');
include('titleheader.php');
if(isset($_POST['submit'])){
    $_POST['submit'] = false;
}
?>
<br><h1 align="center"> Add Students To The Records</h1><br>
<form method="post" action="addstudent.php" enctype="multipart/form-data">
    
    <table align="center" border="1" style="width:70%; margin-top:40px;">


    
        <tr style="height:60px">
             <td colspan="2"  align="center"> <font size="5"><b>Personal Details</b></font></td>
        </tr>
        <tr>
            <th>USN</th>
            <td><input type="text" name="rollno" placeholder="Enter Rollno" required></td>
        </tr>
        <tr>
            <th>Full Name</th>
            <td><input type="text" name="name" placeholder="Enter Full Name" required></td>
        </tr>
        
            <th>Address</th>
            <td><input type="text" name="city" placeholder="Enter Address" required></td>
        </tr>
        <tr>
            <th>Mobile Number</th>
            <td><input type="text" name="pcon" placeholder="Enter  Mobile Number" required></td>
        </tr>
        <tr>
            <th>Semester</th>
            <td><input type="number" name="standard" placeholder="Enter Semester" required></td>
        </tr>
        <tr>
            <th>Image</th>
            <td><input type="file" name="simg" required> </td>
        </tr>






        <tr style="height:60px">
        <td colspan="2"  align="center"> <font size="5"><b>Attendence</b></font></td>
       </tr>
        <tr>
            <th>January</th>
            <td><input type="number" name="jan" placeholder="percentage"></td>
        </tr>
        <tr>
            <th>February</th>
            <td><input type="number" name="feb" placeholder="percentage"></td>
        </tr>
        
            <th>March</th>
            <td><input type="number" name="mar" placeholder="percentage"></td>
        </tr>
        <tr>
            <th>April</th>
            <td><input type="number" name="apr" placeholder="percentage"></td>
        </tr>
        <tr>
            <th>May</th>
            <td><input type="number" name="may" placeholder="percentage"></td>
        </tr>
        <tr>
        <tr>
            <th>June</th>
            <td><input type="number" name="jun"placeholder="percentage" ></td>
        </tr>
        <tr>
            <th>July</th>
            <td><input type="number"name="jul"placeholder="percentage"></td>
        </tr>
        
        <tr>
            <th>Augest</th>
            <td><input type="number" name="aug"placeholder="percentage"></td>
        </tr>
        <tr>
            <th>September</th>
            <td><input type="number" name="sep" placeholder="percentage"></td>
        </tr>
        <tr>
            <th>October</th>
            <td><input type="number" name="oct"placeholder="percentage" ></td>
        </tr>
        <tr>
            <th>November</th>
            <td><input type="number" name="nov" placeholder="percentage"></td>
        </tr>
        <tr>
            <th>Decemberr</th>
            <td><input type="number" name="dec"placeholder="percentage"></td>
        </tr>
        <tr> 
    


        <tr style="height:60px">
        <td colspan="2"  align="center"> <font size="5"><b>Grade Points</b></font></td>
       </tr>
        <tr>
            <th>1st Sem SGPA</th>
            <td><input type="number" name="sem1" placeholder=" Out of 10"></td>
        </tr>
        <tr>
            <th>2nd Sem SGPA</th>
            <td><input type="number" name="sem2" placeholder="Out of 10"></td>
        </tr>
        
            <th>3rd Sem SGPA</th>
            <td><input type="number" name="sem3" placeholder="Out of 10"></td>
        </tr>
        <tr>
            <th>4th Sem SGPA</th>
            <td><input type="number" name="sem4" placeholder="Out of 10"></td>
        </tr>
        <tr>
            <th>5th Sem SGPA</th>
            <td><input type="number" name="sem5" placeholder="Out of 10"></td>
        </tr>
        <tr>
        <tr>
            <th>6th Sem SGPA</th>
            <td><input type="number" name="sem6"placeholder="Out of 10" ></td>
        </tr>
        <tr>
            <th>7th Sem SGPA</th>
            <td><input type="number"name="sem7"placeholder="Out of 10"></td>
        </tr>
        
        <tr>
            <th>8th Sem SGPA</th>
            <td><input type="number" name="sem8"placeholder="Out of 10"></td>
        </tr>
        <tr>
        <tr>
        <th>Current CGPA</th>
            <td><input type="number" name="cgpa"placeholder="Out of 10"></td>
        </tr>
        <tr>


        <tr style="height:60px">
             <td colspan="2"  align="center"> <font size="5"><b>Other Details</b></font></td>
        </tr>
        <tr>
            <th>Date of Birth</th>
            <td><input type="Date" name="dob" placeholder="Enter date of birth" required></td>
        </tr>
        <tr>
            <th>Father Name</th>
            <td><input type="text" name="fname" placeholder="Enter parent name" required></td>
        </tr>
        
            <th>Mother Name</th>
            <td><input type="text" name="mname" placeholder="Enter parent name" required></td>
        </tr>
        <tr>
            <th>Parent Mobile No.</th>
            <td><input type="text" name="pmnum" placeholder="Enter  Mobile Number" required></td>
        </tr>
        

        

        <tr>
            <td colspan="2" align="center"><input type="submit" name="submit" value="Submit"></td>
        </tr>

    </table>
</form>

</body>
</html>

<?php

 if(isset($_POST['submit']))
{
    $con = mysqli_connect('localhost','root','','sms');

	if($con == false){
		echo "Connection not successful";
	 }
    $rollno = $_POST['rollno'];
    $name = $_POST['name'];
    $city = $_POST['city'];
    $pcon = $_POST['pcon'];
    $std = $_POST['standard'];
    $imagename = $_FILES['simg']['name'];
    $tempname = $_FILES['simg']['tmp_name'];

    move_uploaded_file($tempname,"../dataimg/$imagename");

    $jan = $_POST['jan'];
    $feb = $_POST['feb'];
    $mar = $_POST['mar'];
    $apr = $_POST['apr'];
    $may = $_POST['may'];
    $jun = $_POST['jun'];
    $jul = $_POST['jul'];
    $aug = $_POST['aug'];
    $sep = $_POST['sep'];
    $oct = $_POST['oct'];
    $nov = $_POST['nov'];
    $dec = $_POST['dec'];
    $usn = $_POST['rollno'];

    $sem1 = $_POST['sem1'];
    $sem2 = $_POST['sem2'];
    $sem3 = $_POST['sem3'];
    $sem4 = $_POST['sem4'];
    $sem5 = $_POST['sem5'];
    $sem6 = $_POST['sem6'];
    $sem7 = $_POST['sem7'];
    $sem8 = $_POST['sem8'];
    $cgpa = $_POST['cgpa'];

    $dob = $_POST['dob'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $pmnum = $_POST['pmnum'];


        
    

    $qry1 = "INSERT INTO `student`(`name`, `city`, `pcont`, `standard`, `rollno`,`image`) VALUES ('$name','$city','$pcon','$std','$rollno','$imagename')";

    $qry2 = "INSERT INTO `attendence`(`usn`,`jana`, `febr`, `marc`, `apri`, `may`,`june`,`july`, `auge`, `sept`, `octo`, `nove`,`dece`) 
      VALUES ('$usn','$jan','$feb','$mar','$apr','$may','$jun','$jul','$aug','$sep','$oct','$nov','$dec')";

    $qry3 = "INSERT INTO `grade`(`usn`,`semester1`,`semester2` , `semester3`, `semester4`, `semester5`, `semester6`,`semester7`,`semester8`,`cgpa`) 
     VALUES ('$usn','$sem1','$sem2','$sem3','$sem4','$sem5','$sem6','$sem7','$sem8','$cgpa')";

     $qry4 = "INSERT INTO `other`(`usn`, `father`, `mother`, `pnumber`, `DOB`) 
     VALUES ('$usn','$fname','$mname','$pmnum','$dob')";

  
     $run1 = mysqli_multi_query($con,$qry1);
     $run2 = mysqli_multi_query($con,$qry2);
     $run3 = mysqli_multi_query($con,$qry3);
     $run4 = mysqli_multi_query($con,$qry4);
    
    if($run1 == true and $run2 == true and $run3 == true and $run4 == true){
        ?>
        <script>
            alert('Data Inserted Successfully');
        </script>
        <?php
    }
    else
    {
        ?>
        <script>
            alert('unsucessful');
        </script>
        <?php
    }

    
        
}


?>

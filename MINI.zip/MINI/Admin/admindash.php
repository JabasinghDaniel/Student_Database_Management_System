<?php

session_start();
if(isset($_SESSION['uid']))
{
    echo "";
}
/*else{
    header('location: ../login.php');
}*/
 

include('header.php');
?>
<style>
    .button {
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


        .modal {
            font-family: 'Times New Roman', Times, serif;
            font-size: 24px;
  display: none;
  position: fixed; 
  z-index: 1; 
  left: 0;
  top: 0;
  width: 100%; 
  height: 100%; 
  overflow: auto; 
  background-color: rgb(0,0,0); 
  background-color: rgba(0,0,0,0.4);
}
ul {
  list-style-type: none;
  margin: 0px 70px;
  padding: 10px 5px;
  overflow: hidden;
  background-color: #333;

}

li {
  float: center;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 40px 50px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
 </style>
<div class="admintitle" align="center">
<h1  align="center">  Admin Dashboard </h1>
        
        
    </div>
    
    <div class="moda1">
        <table style="width:20%;" align="center">
          <ul>  
              <li style=" font-size: 24px;"><a href="addstudent.php">Add Student</a></li>
              <li style=" font-size: 24px;"><a href="updatestudent.php">Update Student</a></li>
              <li style=" font-size: 24px;"><a href="deletestudent.php">Delete Student</a></li>
              <li style=" font-size: 24px;"><a href="logout.php" >Logout</a></li>
</ul>
</div>
</body>
</html>

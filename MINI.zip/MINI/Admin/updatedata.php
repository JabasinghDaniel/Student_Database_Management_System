<?php

$con = mysqli_connect('localhost','root','','sms');

	if($con == false){
		echo "Connection not successful";
	}

   

    $rollno = $_POST['rollno'];
    $name = $_POST['name'];
    $city = $_POST['city'];
    $pcon = $_POST['pcon'];
    $std = $_POST['standard'];
    $newimage = $_FILES['simg']['name'];
    $tempname = $_FILES['simg']['tmp_name'];
    $id = $_POST['rollno'];

    move_uploaded_file($tempname,"../dataimg/$newimage");

    $jan = $_POST['jan'];
    $feb = $_POST['feb'];
    $mar = $_POST['mar'];
    $apr = $_POST['apr'];
    $may = $_POST['may'];
    $jun = $_POST['jun'];
    $jul = $_POST['jul'];
    $aug = $_POST['aug'];
    $sep = $_POST['sep'];
    $oct = $_POST['oct'];
    $nov = $_POST['nov'];
    $dec = $_POST['dec'];
    $usn = $_POST['rollno'];

    $sem1 = $_POST['sem1'];
    $sem2 = $_POST['sem2'];
    $sem3 = $_POST['sem3'];
    $sem4 = $_POST['sem4'];
    $sem5 = $_POST['sem5'];
    $sem6 = $_POST['sem6'];
    $sem7 = $_POST['sem7'];
    $sem8 = $_POST['sem8'];
    $cgpa = $_POST['cgpa'];

    $dob = $_POST['dob'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $pmnum = $_POST['pmnum'];


    $qry1 = "UPDATE `student` SET `name` = '$name', `city` = '$city', `pcont` = '$pcon', `standard` = '$std', `rollno` = '$rollno', `image` = '$newimage' WHERE `rollno` = '$id';";

    $qry2 = "UPDATE `attendence` SET `jana` = '$jan', `febr` = '$feb', `marc` = '$mar', `apri` = '$apr', `may` = '$may', `june` = '$jun',`july` = '$jul',
             `auge` = '$aug', `sept` = '$sep', `octo` = '$oct', `nove` = '$nov', `dece` = '$dec' WHERE `usn` = '$id';";
    
    $qry3 = "UPDATE `grade` SET `semester1` = '$sem1', `semester2` = '$sem2', `semester3` = '$sem3', `semester4` = '$sem4', `semester5` = '$sem5', `semester6` = '$sem6',`semester7` = '$sem7',
             `semester8` = '$sem8' WHERE `usn` = '$id';";
      
    $qry4 = "UPDATE `other` SET `DOB` = '$dob', `father` = '$fname', `mother` = '$mname', `pnumber` = '$pmnum' WHERE `usn` = '$id';";


    $run1 = mysqli_query($con,$qry1);
    $run2 = mysqli_query($con,$qry2);
    $run3 = mysqli_query($con,$qry3);
    $run4 = mysqli_query($con,$qry4);


    if($run1 == true and $run2 == true and $run3 == true and $run4 == true){
        ?>
        <script>
            alert('Data Updated Successfully');
            window.open('updateform.php?sid=<?php echo $id;?>','self');
        </script>
        <?php
    }
    else
    {
        ?>
        <script>
            alert('unsucessful');
        </script>
        <?php
    }

?>

<?php

session_start();

if(isset($_SESSION['uid']))
{
    header('location:Admin/admindash.php');
}
?>
<html lang="en_US">
    <head>
        <meta charset ="UTF-8">
        <title> Admin Login </title>
        <style>
        .button1 {background-color:white;
    font-family: 'Times New Roman', Times, serif;
            border-radius: 12px;
            border: none;
        color: black;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
            }
        body {font-family: 'Times New Roman', Times, serif;
        background-image: url('dataimg/loginpage.jpg');
        background-repeat: no-repeat;
        background-attachment: fixed;  
        background-size: cover;
}
        </style>
    </head>
    <body>
  
        <h1 align="center"  style="color : black ; font-size: 60px;">Admin Login</h1><br>
        <form action="login.php" method="post">
         <div >   
            <table align="center">
                <tr>
                    <td  style=" font-size: 18px;"><b>Username</b></td><td><input type="text" name="uname"></td>
                </tr>
                <tr>
                    <td style=" font-size: 18px;"><b>Password</b></td><td><input type="password" name="pass"></td>
                </tr>
                <tr>
                    <td colspan="2" align="center" ><input  class=" button1" type="submit" name="login" value="Login"></td>
                </tr>
</div>      
            </table>
            
        </form>
    </body>
</html>

<?php

include('dbcon.php');

if(isset($_POST['login'])){
    
    $username = mysqli_real_escape_string($con,$_POST['uname']);
    $password = mysqli_real_escape_string($con,$_POST['pass']);
    
    $qry = "SELECT * FROM `admin` WHERE `username` = '$username' AND `password` = '$password'";
    
    $run = mysqli_query($con,$qry);
    
    $row = mysqli_num_rows($run);
    
    if($row>=1)
    {
        $data = mysqli_fetch_assoc($run);
        $id = $data['id'];
        
        
        
        $_SESSION['uid']=$id;
        
        header('location:Admin/admindash.php');
        
    }
    else
    {
        ?>
        <script>
            alert('Username Or Password Dont match');
            window.open('login.php','_self')
</script>
        <?php
    }
}

?>